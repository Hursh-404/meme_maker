import cv2
import random
from PIL import Image, ImageDraw, ImageFont
import os

EMOJIS = {
    "happy": "😊",
    "sad": "😢",
    "neutral": "😐"
}

def detect_emotion(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
    eye_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_eye.xml')
    smile_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_smile.xml')

    faces = face_cascade.detectMultiScale(gray, 1.3, 5)
    if len(faces) == 0:
        print("No face detected.")
        return None

    x, y, w, h = faces[0]
    face_roi_gray = gray[y:y+h, x:x+w]

    # Detect eyes
    eyes = eye_cascade.detectMultiScale(face_roi_gray, scaleFactor=1.1, minNeighbors=10, minSize=(20, 20))
    eyes_open = len(eyes) >= 2  # At least two eyes detected

    print(f"Eyes detected: {len(eyes)} (open: {eyes_open})")

    if not eyes_open:
        print("Detected closed eyes. Returning 'sad'.")
        return "sad"

    # Detect smile (in lower face) -- BALANCED VERSION
    mouth_region = face_roi_gray[int(h*0.6):h, 0:w]
    smiles = smile_cascade.detectMultiScale(
        mouth_region, scaleFactor=1.7, minNeighbors=18, minSize=(35, 18)
    )
    smile_detected = False
    for (sx, sy, sw, sh) in smiles:
        if sw > w // 2:
            smile_detected = True
            break

    print(f"Smile count: {len(smiles)}, Smile detected: {smile_detected}")

    if smile_detected:
        return "happy"
    else:
        return "neutral"

def generate_meme(image_path):
    print(f"\n🔄 Processing: {os.path.basename(image_path)}")
    img = cv2.imread(image_path)
    if img is None:
        print(f"❌ Error: Could not read {image_path}")
        print(f"Current folder: {os.getcwd()}")
        print(f"Files here: {os.listdir()}")
        return

    emotion = detect_emotion(img)
    if emotion is None:
        print("\n🤖 Couldn't detect faces properly!")
        while True:
            print("Choose emotion:")
            print("1. Happy")
            print("2. Sad")
            print("3. Neutral")
            choice = input("Enter 1-3: ").strip()

            if choice == "1":
                emotion = "happy"
                break
            elif choice == "2":
                emotion = "sad"
                break
            elif choice == "3":
                emotion = "neutral"
                break
            else:
                print("Invalid choice! Try again.")

    MEMES = {
        "happy": [
            ("WINNING!", "Code works!"),
            ("BUG FIXED!", "Celebrate!")
        ],
        "sad": [
            ("ERROR!", "Why broken?"),
            ("FAILED!", "This shouldn't happen")
        ],
        "neutral": [
            ("HMM...", "Interesting code "),
            ("WELL", "It compiles... ")
        ]
    }

    top_text, bottom_text = random.choice(MEMES[emotion])
    bottom_text = bottom_text + EMOJIS[emotion]

    pil_img = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    draw = ImageDraw.Draw(pil_img)
    try:
        font = ImageFont.truetype("arial.ttf", 50)
    except:
        font = ImageFont.load_default()

    def draw_text(text, y_pos):
        text_width = draw.textlength(text, font=font)
        x = (pil_img.width - text_width) // 2
        for dx, dy in [(-2,-2), (-2,2), (2,-2), (2,2)]:
            draw.text((x+dx, y_pos+dy), text, font=font, fill="black")
        draw.text((x, y_pos), text, font=font, fill="white")

    draw_text(top_text, 20)
    draw_text(bottom_text, pil_img.height - 70)

    output_path = f"{emotion}_meme_{random.randint(100,999)}.jpg"
    pil_img.save(output_path)

    print(f"\n✅ Done! Saved as: {output_path}")
    print(f"Emotion: {emotion}")
    print(f"Caption: {top_text} | {bottom_text}")

if __name__ == "__main__":
    image_file = "sample_image1.jpg"  # CHANGE THIS to your image file
    if os.path.exists(image_file):
        generate_meme(image_file)
    else:
        print(f"❌ File not found. Current files: {os.listdir()}")