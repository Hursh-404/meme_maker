import cv2
import random
from PIL import Image, ImageDraw, ImageFont
import os

EMOJIS = {
    "happy": "😊",
    "sad": "😢",
    "neutral": "😐"
}

def detect_emotion(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
    eye_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_eye.xml')
    smile_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_smile.xml')

    faces = face_cascade.detectMultiScale(gray, 1.3, 5)
    if len(faces) == 0:
        return "neutral"  # fallback for Flask

    x, y, w, h = faces[0]
    face_roi_gray = gray[y:y+h, x:x+w]

    # Detect eyes
    eyes = eye_cascade.detectMultiScale(face_roi_gray, scaleFactor=1.1, minNeighbors=10, minSize=(20, 20))
    eyes_open = len(eyes) >= 2

    if not eyes_open:
        return "sad"

    # Detect smile (in lower face)
    mouth_region = face_roi_gray[int(h*0.6):h, 0:w]
    smiles = smile_cascade.detectMultiScale(
        mouth_region, scaleFactor=1.7, minNeighbors=18, minSize=(35, 18)
    )
    smile_detected = any(sw > w // 2 for (sx, sy, sw, sh) in smiles)

    if smile_detected:
        return "happy"
    else:
        return "neutral"

def generate_meme(image_path):
    img = cv2.imread(image_path)
    if img is None:
        return None  # Error loading image

    emotion = detect_emotion(img)
    MEMES = {
        "happy": [
            ("WINNING!", "Code works!"),
            ("BUG FIXED!", "Celebrate!")
        ],
        "sad": [
            ("ERROR!", "Why broken?"),
            ("FAILED!", "This shouldn't happen")
        ],
        "neutral": [
            ("HMM...", "Interesting code "),
            ("WELL", "It compiles... ")
        ]
    }

    top_text, bottom_text = random.choice(MEMES[emotion])
    bottom_text = bottom_text + EMOJIS[emotion]

    pil_img = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    draw = ImageDraw.Draw(pil_img)
    try:
        font = ImageFont.truetype("arial.ttf", 50)
    except:
        font = ImageFont.load_default()

    def draw_text(text, y_pos):
        text_width = draw.textlength(text, font=font)
        x = (pil_img.width - text_width) // 2
        for dx, dy in [(-2,-2), (-2,2), (2,-2), (2,2)]:
            draw.text((x+dx, y_pos+dy), text, font=font, fill="black")
        draw.text((x, y_pos), text, font=font, fill="white")

    draw_text(top_text, 20)
    draw_text(bottom_text, pil_img.height - 70)

    # Save in uploads folder with unique name
    uploads_dir = "uploads"
    os.makedirs(uploads_dir, exist_ok=True)
    name, ext = os.path.splitext(os.path.basename(image_path))
    output_filename = f"{emotion}_meme_{random.randint(1000,9999)}{ext or '.jpg'}"
    output_path = os.path.join(uploads_dir, output_filename)
    pil_img.save(output_path)

    return output_filename  # just the filename

# This lets Flask import it safely!
if __name__ == "__main__":
    image_file = "sample_image1.jpg"
    if os.path.exists(image_file):
        print("Saving test meme to uploads folder...")
        generate_meme(image_file)
    else:
        print(f"❌ File not found. Current files: {os.listdir()}")